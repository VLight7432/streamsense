const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const dotenv = require('dotenv');
const { listStreams } = require('./services/streamsService');

// Charger les variables d'environnement
dotenv.config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json());

// Endpoint de santé
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'streamsense-backend' });
});

// Route réelle : liste des streams depuis Supabase
app.get('/streams', async (req, res) => {
  try {
    const streams = await listStreams();
    res.json({ streams });
  } catch (e) {
    console.error('[StreamSense backend] /streams error', e);
    res.status(500).json({ error: 'internal_error' });
  }
});

// Route de démo : métriques simulées pour la bêta
app.get('/metrics/demo', (req, res) => {
  const now = Date.now();

  const metrics = [
    {
      streamId: 'transactions',
      metric: 'transactions_per_second',
      unit: '/s',
      value: 400 + Math.round(Math.random() * 80),
      timestamp: new Date(now).toISOString(),
    },
    {
      streamId: 'errors',
      metric: 'error_rate',
      unit: '%',
      value: +(0.8 + Math.random() * 1.2).toFixed(2),
      timestamp: new Date(now).toISOString(),
    },
    {
      streamId: 'latency',
      metric: 'p95_latency',
      unit: 'ms',
      value: 160 + Math.round(Math.random() * 50),
      timestamp: new Date(now).toISOString(),
    },
  ];

  res.json({ metrics });
});

// WebSocket basique pour la bêta (echo + logs)
wss.on('connection', (ws) => {
  console.log('[StreamSense backend] WebSocket client connected');

  ws.on('message', (message) => {
    const text = message.toString();
    console.log('[StreamSense backend] WS message:', text);
    // Echo simple pour l’instant
    ws.send(JSON.stringify({ type: 'echo', payload: text }));
  });

  ws.on('error', (err) => {
    console.error('[StreamSense backend] WS error:', err);
  });

  ws.on('close', () => {
    console.log('[StreamSense backend] WebSocket client disconnected');
  });
});

const PORT = process.env.PORT || 4000;

server.listen(PORT, () => {
  console.log(`[StreamSense backend] Listening on http://localhost:${PORT}`);
});
